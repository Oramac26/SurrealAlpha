#ifndef SCREENS_HPP_INCLUDED
#define SCREENS_HPP_INCLUDED

#include "cScreen.hpp"
#include "Menu.hpp"
#include "Game.hpp"
#include "Credits.hpp"

#endif