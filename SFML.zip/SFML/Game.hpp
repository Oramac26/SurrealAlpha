#include <iostream>
#include "cScreen.hpp"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <sstream>
#include <vector>
#include <string>
#include <Windows.h>

#define BARLENGTH 3.27
#define XALL 894
#define YAGILITY 48
#define YSCAVENGING 81
#define YCRAFTING 113
#define xp 227
#define yp 24

class GameScr:public cScreen{

public:
	virtual int Run(sf::RenderWindow &win);

	bool CorrectM(sf::Sprite &s, const sf::RenderWindow &w)
	{
	if (
	sf::Mouse::getPosition(w).x > s.getGlobalBounds().left &&
	sf::Mouse::getPosition(w).y > s.getGlobalBounds().top &&
	sf::Mouse::getPosition(w).x < s.getGlobalBounds().left + s.getGlobalBounds().width &&
	sf::Mouse::getPosition(w).y < s.getGlobalBounds().top + s.getGlobalBounds().height
	)
	return 1;
	else
	return 0;
	}

	void dispSkill(int x,int y,sf::Texture &skill,sf::Text &text,sf::Sprite &s,int bar,int lvl)
	{
	std::ostringstream ss;
	ss<<lvl;
	text.setString(ss.str());
	skill.loadFromFile( "Barcut.png" , sf::IntRect(0,0,BARLENGTH*bar,7));
	s.setTexture( skill );
	s.setPosition(x+12,y+5);
	text.setPosition(x,y);
	}

	void dispParameter(sf::Text &text,int lvl,int x,int y)
	{
		std::ostringstream ss;
		ss<<lvl;
		text.setString(ss.str());
		text.setPosition(x,y);
	}
	//1 - home, 2 - forest, 3 - city, 4 - tunnels
	void dispLoc(sf::Texture &loc,sf::Sprite &s,int parameter)
	{
		if (parameter==1) loc.loadFromFile("home.png");
		if (parameter==2) loc.loadFromFile("forest.png");
		if (parameter==3) loc.loadFromFile("city.png");
		if (parameter==4) loc.loadFromFile("tunnels.png");
		s.setTexture( loc );
		s.setPosition(17,35);
	}
	void dispWeapon(sf::Texture &w,sf::Sprite &s,sf::Text &text, int parameter,bool ranged,int name)
	{
		std::ostringstream ss;
		ss<<name;
		text.setString(ss.str());
		if (ranged==true){
			if (parameter==1) w.loadFromFile("slingshot.png");
			if (parameter==2) w.loadFromFile("bow.png");
			if (parameter==3) w.loadFromFile("crossbow.png");
			s.setTexture( w );
			s.setPosition(1150,360);
			text.setPosition(1160,481);
		}
		else
		{
			if (parameter==1) w.loadFromFile("stick.png");
			if (parameter==2) w.loadFromFile("knife.png");
			if (parameter==3) w.loadFromFile("axe.png");
			s.setTexture( w );
			s.setPosition(1150,190);
			text.setPosition(1160,305);
		}
	}
	void dispHours(sf::Text &text,int hours)
	{
		std::ostringstream ss;
		ss<<hours;
		text.setString(ss.str());
		text.setPosition(592,541);
	}
	void dispChoice(sf::Text &text,int parameter)
	{
		if (parameter==2) text.setString("forest");
		if (parameter==3) text.setString("city");
		if (parameter==4) text.setString("tunnels");
		text.setPosition(592,501);
	}
};

int GameScr::Run(sf::RenderWindow &win){
 
	bool Running=true,com=true;
	int MeleeParameter=1,RangedParameter=1,Hours=2,LocationParameter=2;
	std::vector <std::string> sentence;
	std::string new_sentence,SkillName;

    sf::Texture obr1,obr2,obr3,obr4,skill,loc,weap,obr5,obr6,obr7,obr8;
    obr1.loadFromFile( "MainScr.png" );
	obr2.loadFromFile( "Inventoryclc.png" );
	obr3.loadFromFile( "Goclc.png" );
	obr4.loadFromFile( "Hideoutclc.png" );
	obr5.loadFromFile( "ArrowUp.png" );
	obr6.loadFromFile( "ArrowDown.png" );
	obr7.loadFromFile( "Plus.png" );
	obr8.loadFromFile( "Minus.png" );

	sf::Sprite bg,inv,go,hide,bar,bar2,bar3,location,weapon,ArrowUpR,ArrowDownR,ArrowUpM,ArrowDownM,plus,minus,plusLoc,minusLoc;
    bg.setTexture( obr1 );	
	inv.setTexture( obr2 );
	go.setTexture( obr3 );
	hide.setTexture( obr4 );
	ArrowUpR.setTexture( obr5 );
	ArrowDownR.setTexture( obr6 );
	ArrowUpM.setTexture( obr5 );
	ArrowDownM.setTexture( obr6 );
	plus.setTexture( obr7 );
	minus.setTexture( obr8 );
	plusLoc.setTexture( obr7 );
	minusLoc.setTexture( obr8 );

	plusLoc.setPosition(730,498);
	minusLoc.setPosition(514,498);

	minus.setPosition(514,538);
	plus.setPosition(730,538);

	ArrowUpR.setPosition(1090,420);
	ArrowDownR.setPosition(1090,464);
	ArrowUpM.setPosition(1090,241);
	ArrowDownM.setPosition(1090,285);

	inv.setPosition(781,627);
	go.setPosition(505,574);
	hide.setPosition(199,626);

	sf::Font font;
	font.loadFromFile("28.ttf");
	sf::Text level,communicate,parameter,Sname,weaponname,weaponname2,TextH,Choice;

	Choice.setFont(font);
	Choice.setCharacterSize(30);
	Choice.setColor(sf::Color::White);

	TextH.setFont(font);
	TextH.setCharacterSize(30);
	TextH.setColor(sf::Color::White);

	weaponname.setFont(font);
	weaponname.setCharacterSize(15);
	weaponname.setColor(sf::Color::White);

	weaponname2.setFont(font);
	weaponname2.setCharacterSize(15);
	weaponname2.setColor(sf::Color::White);

	Sname.setFont(font);
	Sname.setCharacterSize(15);
	Sname.setColor(sf::Color::White);

	level.setFont(font);
	level.setCharacterSize(15);
	level.setColor(sf::Color::White);

	communicate.setFont(font);
	communicate.setCharacterSize(15);
	communicate.setColor(sf::Color::White);

	parameter.setFont(font);
	parameter.setCharacterSize(25);
	parameter.setColor(sf::Color::White);

	sf::Event zdarzenie;
	while (Running){

        while( win.pollEvent( zdarzenie ) )
        {
			if( zdarzenie.type == sf::Event::KeyReleased && zdarzenie.key.code == sf::Keyboard::Escape ) return (0);
			if (zdarzenie.type == sf::Event::Closed)
            {
                return (-1);
            }
		}

	win.draw(bg);

	dispSkill(XALL,YAGILITY,skill,level,bar,20,4);	
	win.draw( bar );
	win.draw( level );

	dispSkill(XALL,YSCAVENGING,skill,level,bar2,10,3);
	win.draw( bar2 );
	win.draw( level );

	dispSkill(XALL,YCRAFTING,skill,level,bar3,70,6);
	win.draw( bar3 );
	win.draw( level );

	dispParameter(parameter,18,xp,yp);
	win.draw(parameter);

	dispParameter(parameter,100,xp,yp+30);
	win.draw(parameter);

	dispLoc(loc,location,1);
	win.draw( location );

	dispWeapon(weap,weapon,weaponname,MeleeParameter,false,MeleeParameter);
	win.draw(weaponname);
	win.draw(weapon);

	dispWeapon(weap,weapon,weaponname2,RangedParameter,true,RangedParameter);
	win.draw(weaponname2);
	win.draw(weapon);

	dispHours(TextH,Hours);
	win.draw(TextH);

	dispChoice(Choice,LocationParameter);
	win.draw(Choice);

	if (com==true){
		sentence.push_back("welcome to surreal beta!");
		com=false;
	}

	if (sentence.size()>9) sentence.erase(sentence.begin());

	for (int i=0;i<sentence.size();i++)
	{
		std::ostringstream s2;
		s2<<sentence[i];
		communicate.setString(s2.str());
		communicate.setPosition(432,19+(i*20));
		win.draw(communicate);
	}

	if (CorrectM(ArrowUpR, win)) {
				win.draw( ArrowUpR );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left ) 
				{
					if (RangedParameter<3) RangedParameter++;
					Sleep(70);
				}
			}
	
	if (CorrectM(ArrowDownR, win)) {
				win.draw( ArrowDownR );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left ) 
				{
					if (RangedParameter>1) RangedParameter--;
					Sleep(70);
				}
			}

	if (CorrectM(ArrowUpM, win)) {
				win.draw( ArrowUpM );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left )
				{
					if (MeleeParameter<3) MeleeParameter++;
					Sleep(70);
				}
			}

	if (CorrectM(ArrowDownM, win)) {
				win.draw( ArrowDownM );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left ) 
				{
					if (MeleeParameter>1) MeleeParameter--;
					Sleep(70);
				}
			}

	if (CorrectM(plus, win)) {
				win.draw( plus );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left ) 
				{
					if (Hours<8) Hours++;
					Sleep(70);
				}
			}

	if (CorrectM(minus, win)) {
				win.draw( minus );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left ) 
				{
					if (Hours>2) Hours--;
					Sleep(70);
				}
			}
	if (CorrectM(minusLoc, win)) {
				win.draw( minusLoc );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left ) 
				{
					if (LocationParameter>2) LocationParameter--;
					Sleep(70);
				}
			}
	if (CorrectM(plusLoc, win)) {
				win.draw( plusLoc );
				if ( zdarzenie.type == sf::Event::MouseButtonPressed && zdarzenie.mouseButton.button == sf::Mouse::Left ) 
				{
					if (LocationParameter<4) LocationParameter++;
					Sleep(70);
				}
			}

	if (CorrectM(inv, win)) {
				win.draw( inv );
			}
	if (CorrectM(go, win)) {
				win.draw( go );
			}
	if (CorrectM(hide, win)) {
				win.draw( hide );
			}

	win.display();
	}

	return (-1);
}